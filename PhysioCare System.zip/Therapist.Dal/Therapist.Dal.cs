﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic.DAL
{
    public class TherapistDAL
    {
        public void Add(Therapist t)
        {
            string sql = "INSERT INTO Therapist (FullName, Specialty, Phone) VALUES (@n,@s,@ph)";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", t.FullName);
                cmd.Parameters.AddWithValue("@s", string.IsNullOrEmpty(t.Specialty) ? (object)DBNull.Value : t.Specialty);
                cmd.Parameters.AddWithValue("@ph", string.IsNullOrEmpty(t.Phone) ? (object)DBNull.Value : t.Phone);
                try { conn.Open(); cmd.ExecuteNonQuery(); }
                catch (Exception ex) { throw new Exception("TherapistDAL.Add -> " + ex.Message); }
            }
        }

        public List<Therapist> GetAll()
        {
            var list = new List<Therapist>();
            string sql = "SELECT TherapistId, FullName, Specialty, Phone FROM Therapist ORDER BY TherapistId";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var t = new Therapist
                            {
                                TherapistId = reader.GetInt32(reader.GetOrdinal("TherapistId")),
                                FullName = reader.GetString(reader.GetOrdinal("FullName")),
                                Specialty = reader.IsDBNull(reader.GetOrdinal("Specialty")) ? "" : reader.GetString(reader.GetOrdinal("Specialty")),
                                Phone = reader.IsDBNull(reader.GetOrdinal("Phone")) ? "" : reader.GetString(reader.GetOrdinal("Phone"))
                            };
                            list.Add(t);
                        }
                    }
                }
                catch (Exception ex) { throw new Exception("TherapistDAL.GetAll -> " + ex.Message); }
            }
            return list;
        }

        public void Update(Therapist t)
        {
            string sql = "UPDATE Therapist SET FullName=@n, Specialty=@s, Phone=@ph WHERE TherapistId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", t.FullName);
                cmd.Parameters.AddWithValue("@s", string.IsNullOrEmpty(t.Specialty) ? (object)DBNull.Value : t.Specialty);
                cmd.Parameters.AddWithValue("@ph", string.IsNullOrEmpty(t.Phone) ? (object)DBNull.Value : t.Phone);
                cmd.Parameters.AddWithValue("@id", t.TherapistId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No therapist updated."); }
                catch (Exception ex) { throw new Exception("TherapistDAL.Update -> " + ex.Message); }
            }
        }

        public void Delete(int therapistId)
        {
            string sql = "DELETE FROM Therapist WHERE TherapistId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", therapistId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No therapist to delete."); }
                catch (Exception ex) { throw new Exception("TherapistDAL.Delete -> " + ex.Message); }
            }
        }
    }
}
