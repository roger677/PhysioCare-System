﻿using System.Data.SqlClient;

namespace PhysiotherapyClinic.DAL
{
    public static class Database
    {
        private static string _connectionString = "Server=localhost\\SQLEXPRESS;Database=PhysiotherapyClinicDB;Trusted_Connection=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
