﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic.DAL
{
    public class PatientDAL
    {
        public void Add(Patient p)
        {
            string sql = "INSERT INTO Patient (FullName, Age, Phone, Email, Notes) VALUES (@n,@a,@ph,@em,@no)";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", p.FullName);
                cmd.Parameters.AddWithValue("@a", p.Age);
                cmd.Parameters.AddWithValue("@ph", string.IsNullOrEmpty(p.Phone) ? (object)DBNull.Value : p.Phone);
                cmd.Parameters.AddWithValue("@em", string.IsNullOrEmpty(p.Email) ? (object)DBNull.Value : p.Email);
                cmd.Parameters.AddWithValue("@no", string.IsNullOrEmpty(p.Notes) ? (object)DBNull.Value : p.Notes);

                try { conn.Open(); cmd.ExecuteNonQuery(); }
                catch (Exception ex) { throw new Exception("PatientDAL.Add -> " + ex.Message); }
            }
        }

        public List<Patient> GetAll()
        {
            var list = new List<Patient>();
            string sql = "SELECT PatientId, FullName, Age, Phone, Email, Notes FROM Patient ORDER BY PatientId";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var p = new Patient
                            {
                                PatientId = reader.GetInt32(reader.GetOrdinal("PatientId")),
                                FullName = reader.GetString(reader.GetOrdinal("FullName")),
                                Age = reader.GetInt32(reader.GetOrdinal("Age")),
                                Phone = reader.IsDBNull(reader.GetOrdinal("Phone")) ? "" : reader.GetString(reader.GetOrdinal("Phone")),
                                Email = reader.IsDBNull(reader.GetOrdinal("Email")) ? "" : reader.GetString(reader.GetOrdinal("Email")),
                                Notes = reader.IsDBNull(reader.GetOrdinal("Notes")) ? "" : reader.GetString(reader.GetOrdinal("Notes"))
                            };
                            list.Add(p);
                        }
                    }
                }
                catch (Exception ex) { throw new Exception("PatientDAL.GetAll -> " + ex.Message); }
            }
            return list;
        }

        public void Update(Patient p)
        {
            string sql = "UPDATE Patient SET FullName=@n, Age=@a, Phone=@ph, Email=@em, Notes=@no WHERE PatientId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", p.FullName);
                cmd.Parameters.AddWithValue("@a", p.Age);
                cmd.Parameters.AddWithValue("@ph", string.IsNullOrEmpty(p.Phone) ? (object)DBNull.Value : p.Phone);
                cmd.Parameters.AddWithValue("@em", string.IsNullOrEmpty(p.Email) ? (object)DBNull.Value : p.Email);
                cmd.Parameters.AddWithValue("@no", string.IsNullOrEmpty(p.Notes) ? (object)DBNull.Value : p.Notes);
                cmd.Parameters.AddWithValue("@id", p.PatientId);

                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No patient updated."); }
                catch (Exception ex) { throw new Exception("PatientDAL.Update -> " + ex.Message); }
            }
        }

        public void Delete(int patientId)
        {
            string sql = "DELETE FROM Patient WHERE PatientId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", patientId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No patient to delete."); }
                catch (Exception ex) { throw new Exception("PatientDAL.Delete -> " + ex.Message); }
            }
        }
    }
}
