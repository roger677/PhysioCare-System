﻿using System;

namespace PhysiotherapyClinic.Models
{
    public class SessionRecord
    {
        public int SessionId { get; set; }
        public int PatientId { get; set; }
        public int TherapistId { get; set; }
        public int? TreatmentId { get; set; }
        public DateTime SessionDate { get; set; }
        public string Notes { get; set; }
    }
}
