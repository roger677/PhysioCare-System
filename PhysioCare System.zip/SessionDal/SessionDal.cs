﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic.DAL
{
    public class SessionDAL
    {
        public void Add(SessionRecord s)
        {
            string sql = @"INSERT INTO SessionRecord (PatientId, TherapistId, TreatmentId, SessionDate, Notes)
                           VALUES (@p,@t,@tr,@date,@notes)";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@p", s.PatientId);
                cmd.Parameters.AddWithValue("@t", s.TherapistId);
                cmd.Parameters.AddWithValue("@tr", s.TreatmentId.HasValue ? (object)s.TreatmentId.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@date", s.SessionDate);
                cmd.Parameters.AddWithValue("@notes", string.IsNullOrEmpty(s.Notes) ? (object)DBNull.Value : s.Notes);

                try { conn.Open(); cmd.ExecuteNonQuery(); }
                catch (Exception ex) { throw new Exception("SessionDAL.Add -> " + ex.Message); }
            }
        }

        public List<SessionRecord> GetAll()
        {
            var list = new List<SessionRecord>();
            string sql = "SELECT SessionId, PatientId, TherapistId, TreatmentId, SessionDate, Notes FROM SessionRecord ORDER BY SessionDate DESC";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var s = new SessionRecord
                            {
                                SessionId = reader.GetInt32(reader.GetOrdinal("SessionId")),
                                PatientId = reader.GetInt32(reader.GetOrdinal("PatientId")),
                                TherapistId = reader.GetInt32(reader.GetOrdinal("TherapistId")),
                                TreatmentId = reader.IsDBNull(reader.GetOrdinal("TreatmentId")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("TreatmentId")),
                                SessionDate = reader.GetDateTime(reader.GetOrdinal("SessionDate")),
                                Notes = reader.IsDBNull(reader.GetOrdinal("Notes")) ? "" : reader.GetString(reader.GetOrdinal("Notes"))
                            };
                            list.Add(s);
                        }
                    }
                }
                catch (Exception ex) { throw new Exception("SessionDAL.GetAll -> " + ex.Message); }
            }
            return list;
        }

        public void Delete(int sessionId)
        {
            string sql = "DELETE FROM SessionRecord WHERE SessionId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", sessionId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No session to delete."); }
                catch (Exception ex) { throw new Exception("SessionDAL.Delete -> " + ex.Message); }
            }
        }
    }
}
