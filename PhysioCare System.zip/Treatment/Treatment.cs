﻿namespace PhysiotherapyClinic.Models
{
    public class Treatment
    {
        public int TreatmentId { get; set; }
        public string TreatmentName { get; set; }
        public string Description { get; set; }
    }
}
