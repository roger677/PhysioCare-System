﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic.DAL
{
    public class TreatmentDAL
    {
        public void Add(Treatment t)
        {
            string sql = "INSERT INTO Treatment (TreatmentName, Description) VALUES (@n,@d)";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", t.TreatmentName);
                cmd.Parameters.AddWithValue("@d", string.IsNullOrEmpty(t.Description) ? (object)DBNull.Value : t.Description);
                try { conn.Open(); cmd.ExecuteNonQuery(); }
                catch (Exception ex) { throw new Exception("TreatmentDAL.Add -> " + ex.Message); }
            }
        }

        public List<Treatment> GetAll()
        {
            var list = new List<Treatment>();
            string sql = "SELECT TreatmentId, TreatmentName, Description FROM Treatment ORDER BY TreatmentId";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var t = new Treatment
                            {
                                TreatmentId = reader.GetInt32(reader.GetOrdinal("TreatmentId")),
                                TreatmentName = reader.GetString(reader.GetOrdinal("TreatmentName")),
                                Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? "" : reader.GetString(reader.GetOrdinal("Description"))
                            };
                            list.Add(t);
                        }
                    }
                }
                catch (Exception ex) { throw new Exception("TreatmentDAL.GetAll -> " + ex.Message); }
            }
            return list;
        }

        public void Update(Treatment t)
        {
            string sql = "UPDATE Treatment SET TreatmentName=@n, Description=@d WHERE TreatmentId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@n", t.TreatmentName);
                cmd.Parameters.AddWithValue("@d", string.IsNullOrEmpty(t.Description) ? (object)DBNull.Value : t.Description);
                cmd.Parameters.AddWithValue("@id", t.TreatmentId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No treatment updated."); }
                catch (Exception ex) { throw new Exception("TreatmentDAL.Update -> " + ex.Message); }
            }
        }

        public void Delete(int treatmentId)
        {
            string sql = "DELETE FROM Treatment WHERE TreatmentId=@id";
            using (var conn = Database.GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", treatmentId);
                try { conn.Open(); int rows = cmd.ExecuteNonQuery(); if (rows == 0) throw new Exception("No treatment to delete."); }
                catch (Exception ex) { throw new Exception("TreatmentDAL.Delete -> " + ex.Message); }
            }
        }
    }
}
