﻿using System;
using PhysiotherapyClinic.BLL;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic
{
    class Program
    {
        static ClinicService clinic = new ClinicService();

        static void Main(string[] args)
        {
            Console.WriteLine("=== PHYSIOTHERAPY CLINIC MANAGER (Layers: UI - BLL - DAL) ===\n");

            bool running = true;
            while (running)
            {
                ShowMenu();
                Console.Write("Choose option: ");
                string opt = Console.ReadLine();
                Console.WriteLine();

                try
                {
                    switch (opt)
                    {
                        case "1": AddPatientFlow(); break;
                        case "2": ListPatientsFlow(); break;
                        case "3": UpdatePatientFlow(); break;
                        case "4": DeletePatientFlow(); break;
                        case "5": AddTherapistFlow(); break;
                        case "6": ListTherapistsFlow(); break;
                        case "7": AddTreatmentFlow(); break;
                        case "8": ListTreatmentsFlow(); break;
                        case "9": AddSessionFlow(); break;
                        case "10": ListSessionsFlow(); break;
                        case "0": running = false; break;
                        default: Console.WriteLine("Please choose a valid option."); break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Operation error: " + ex.Message);
                }

                Console.WriteLine();
            }

            Console.WriteLine("Exiting. Press any key.");
            Console.ReadKey();
        }

        static void ShowMenu()
        {
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. List Patients");
            Console.WriteLine("3. Update Patient");
            Console.WriteLine("4. Delete Patient");
            Console.WriteLine("5. Add Therapist");
            Console.WriteLine("6. List Therapists");
            Console.WriteLine("7. Add Treatment");
            Console.WriteLine("8. List Treatments");
            Console.WriteLine("9. Add Session");
            Console.WriteLine("10. List Sessions");
            Console.WriteLine("0. Exit");
        }

        // --- Patient flows
        static void AddPatientFlow()
        {
            Console.WriteLine("-- Add Patient --");
            Console.Write("Full name: "); string name = Console.ReadLine();
            Console.Write("Age: "); int age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Phone (optional): "); string phone = Console.ReadLine();
            Console.Write("Email (optional): "); string email = Console.ReadLine();
            Console.Write("Notes (optional): "); string notes = Console.ReadLine();

            var p = new Patient { FullName = name, Age = age, Phone = phone, Email = email, Notes = notes };
            clinic.AddPatient(p);
            Console.WriteLine("Patient created.");
        }

        static void ListPatientsFlow()
        {
            Console.WriteLine("-- Patients --");
            var list = clinic.GetAllPatients();
            foreach (var p in list)
            {
                Console.WriteLine($"{p.PatientId} | {p.FullName} | Age: {p.Age} | Phone: {p.Phone} | Email: {p.Email}");
            }
        }

        static void UpdatePatientFlow()
        {
            Console.WriteLine("-- Update Patient --");
            Console.Write("Patient ID: "); int id = Convert.ToInt32(Console.ReadLine());
            Console.Write("New Full name: "); string name = Console.ReadLine();
            Console.Write("New Age: "); int age = Convert.ToInt32(Console.ReadLine());
            Console.Write("New Phone: "); string phone = Console.ReadLine();
            Console.Write("New Email: "); string email = Console.ReadLine();
            Console.Write("New Notes: "); string notes = Console.ReadLine();

            var p = new Patient { PatientId = id, FullName = name, Age = age, Phone = phone, Email = email, Notes = notes };
            clinic.UpdatePatient(p);
            Console.WriteLine("Patient updated.");
        }

        static void DeletePatientFlow()
        {
            Console.WriteLine("-- Delete Patient --");
            Console.Write("Patient ID: "); int id = Convert.ToInt32(Console.ReadLine());
            clinic.DeletePatient(id);
            Console.WriteLine("Patient deleted (if existed).");
        }

        // --- Therapist flows
        static void AddTherapistFlow()
        {
            Console.WriteLine("-- Add Therapist --");
            Console.Write("Full name: "); string name = Console.ReadLine();
            Console.Write("Specialty (optional): "); string spec = Console.ReadLine();
            Console.Write("Phone (optional): "); string phone = Console.ReadLine();

            var t = new Therapist { FullName = name, Specialty = spec, Phone = phone };
            clinic.AddTherapist(t);
            Console.WriteLine("Therapist created.");
        }

        static void ListTherapistsFlow()
        {
            Console.WriteLine("-- Therapists --");
            var list = clinic.GetAllTherapists();
            foreach (var t in list)
            {
                Console.WriteLine($"{t.TherapistId} | {t.FullName} | Specialty: {t.Specialty} | Phone: {t.Phone}");
            }
        }

        // --- Treatment flows
        static void AddTreatmentFlow()
        {
            Console.WriteLine("-- Add Treatment --");
            Console.Write("Treatment name: "); string name = Console.ReadLine();
            Console.Write("Description (optional): "); string desc = Console.ReadLine();

            var tr = new Treatment { TreatmentName = name, Description = desc };
            clinic.AddTreatment(tr);
            Console.WriteLine("Treatment created.");
        }

        static void ListTreatmentsFlow()
        {
            Console.WriteLine("-- Treatments --");
            var list = clinic.GetAllTreatments();
            foreach (var t in list)
            {
                Console.WriteLine($"{t.TreatmentId} | {t.TreatmentName} | {t.Description}");
            }
        }

        // --- Session flows
        static void AddSessionFlow()
        {
            Console.WriteLine("-- Add Session --");
            Console.Write("Patient ID: "); int pid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Therapist ID: "); int tid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Treatment ID (0 = none): "); int trid = Convert.ToInt32(Console.ReadLine());
            int? trNullable = trid == 0 ? (int?)null : trid;
            Console.Write("Session date/time (yyyy-MM-dd HH:mm, optional): "); string dtTxt = Console.ReadLine();

            DateTime dt;
            if (!DateTime.TryParse(dtTxt, out dt)) dt = DateTime.Now;

            Console.Write("Notes (optional): "); string notes = Console.ReadLine();

            var s = new SessionRecord { PatientId = pid, TherapistId = tid, TreatmentId = trNullable, SessionDate = dt, Notes = notes };
            clinic.AddSession(s);
            Console.WriteLine("Session created.");
        }

        static void ListSessionsFlow()
        {
            Console.WriteLine("-- Sessions --");
            var list = clinic.GetAllSessions();
            foreach (var s in list)
            {
                string tr = s.TreatmentId.HasValue ? s.TreatmentId.Value.ToString() : "N/A";
                Console.WriteLine($"{s.SessionId} | Date: {s.SessionDate} | PatientId: {s.PatientId} | TherapistId: {s.TherapistId} | TreatmentId: {tr} | Notes: {s.Notes}");
            }
        }
    }
}
