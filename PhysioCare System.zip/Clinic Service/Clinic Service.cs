﻿using System;
using System.Collections.Generic;
using PhysiotherapyClinic.DAL;
using PhysiotherapyClinic.Models;

namespace PhysiotherapyClinic.BLL
{
    public class ClinicService
    {
        private PatientDAL _patientDal = new PatientDAL();
        private TherapistDAL _therapistDal = new TherapistDAL();
        private TreatmentDAL _treatmentDal = new TreatmentDAL();
        private SessionDAL _sessionDal = new SessionDAL();

        // Patient operations 
        public void AddPatient(Patient p)
        {
            if (string.IsNullOrWhiteSpace(p.FullName)) throw new ArgumentException("Patient name required.");
            if (p.Age <= 0) throw new ArgumentException("Patient age must be > 0.");
            _patientDal.Add(p);
        }

        public List<Patient> GetAllPatients() => _patientDal.GetAll();

        public void UpdatePatient(Patient p)
        {
            if (p.PatientId <= 0) throw new ArgumentException("Invalid patient id.");
            _patientDal.Update(p);
        }

        public void DeletePatient(int id)
        {
            if (id <= 0) throw new ArgumentException("Invalid patient id.");
            _patientDal.Delete(id);
        }

        // Therapist operations
        public void AddTherapist(Therapist t)
        {
            if (string.IsNullOrWhiteSpace(t.FullName)) throw new ArgumentException("Therapist name required.");
            _therapistDal.Add(t);
        }

        public List<Therapist> GetAllTherapists() => _therapistDal.GetAll();

        public void UpdateTherapist(Therapist t) => _therapistDal.Update(t);

        public void DeleteTherapist(int id) => _therapistDal.Delete(id);

        // Treatment operations
        public void AddTreatment(Treatment t)
        {
            if (string.IsNullOrWhiteSpace(t.TreatmentName)) throw new ArgumentException("Treatment name required.");
            _treatmentDal.Add(t);
        }

        public List<Treatment> GetAllTreatments() => _treatmentDal.GetAll();

        public void UpdateTreatment(Treatment t) => _treatmentDal.Update(t);

        public void DeleteTreatment(int id) => _treatmentDal.Delete(id);

        // Session operations
        public void AddSession(SessionRecord s)
        {
            if (s.PatientId <= 0) throw new ArgumentException("Invalid patient id.");
            if (s.TherapistId <= 0) throw new ArgumentException("Invalid therapist id.");
            if (s.SessionDate == default(DateTime)) s.SessionDate = DateTime.Now;
            _sessionDal.Add(s);
        }

        public List<SessionRecord> GetAllSessions() => _sessionDal.GetAll();

        public void DeleteSession(int id) => _sessionDal.Delete(id);
    }
}
