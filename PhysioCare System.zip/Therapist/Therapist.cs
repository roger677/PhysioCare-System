﻿namespace PhysiotherapyClinic.Models
{
    public class Therapist
    {
        public int TherapistId { get; set; }
        public string FullName { get; set; }
        public string Specialty { get; set; }
        public string Phone { get; set; }
    }
}
